<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<div>
		<label class="screen-reader-text" for="s"><?php echo __( 'Search for:', 'read' ); ?></label>
		<input type="text" id="s" name="s" placeholder="<?php echo __( 'Enter keyword...', 'read' ); ?>" value="<?php the_search_query(); ?>">
		<input type="submit" id="searchsubmit" value="<?php echo __( 'Search', 'read' ); ?>">
	</div>
</form>